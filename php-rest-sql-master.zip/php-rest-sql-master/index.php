<?php

require_once('phprestsql.php');

$PHPRestSQL =& new PHPRestSQL();
$PHPRestSQL->exec();

/*
echo '<pre>';
var_dump($PHPRestSQL->output);
//*/

?>